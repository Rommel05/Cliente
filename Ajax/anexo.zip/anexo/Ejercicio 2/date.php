<?php
    $currentDate = date("Y-m-d H:i:s");
    echo $currentDate;
?>